package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApapTutorial04Application
{

    public static void main (String[] args)
    {
        SpringApplication.run (ApapTutorial04Application.class, args);
    }
}
